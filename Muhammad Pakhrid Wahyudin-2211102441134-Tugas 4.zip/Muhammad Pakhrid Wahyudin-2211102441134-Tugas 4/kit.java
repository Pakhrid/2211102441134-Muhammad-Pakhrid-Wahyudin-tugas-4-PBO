import greenfoot.*; // Import Greenfoot library

public class kit extends Actor {
    public void act() {
        Actor kelinci = getWorld().getObjects(kelinci.class).get(0); // Dapatkan referensi ke Pac-Man

        // Hitung sudut arah menuju Pac-Man
        int targetX = kelinci.getX();
        int targetY = kelinci.getY();
        int currentX = getX();
        int currentY = getY();

        int deltaX = targetX - currentX;
        int deltaY = targetY - currentY;

        double angle = Math.toDegrees(Math.atan2(deltaY, deltaX));

        // Set sudut putaran musuh agar menghadap Pac-Man
        setRotation((int)angle);

        // Gerakkan musuh menuju Pac-Man
        move(1);

        // Deteksi tabrakan dengan Pac-Man (kelinci)
        if (isTouching(kelinci.class)) {
            removeTouching(kelinci.class); // Hapus objek Pac-Man (kelinci) saat terjadi tabrakan
        }
    }
}
