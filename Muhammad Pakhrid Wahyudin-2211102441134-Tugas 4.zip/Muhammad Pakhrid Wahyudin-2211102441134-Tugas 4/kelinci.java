import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Kelinci here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

 
public class kelinci extends Actor
{
    /**
     * Act - do whatever the Kelinci wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int JumlahWortelDimakan = 0;
    public void act() 
    {
        if(Greenfoot.isKeyDown("up")){
            setImage("kelinci-up.png");
            setLocation(getX(),getY()-2);
        }
        if(Greenfoot.isKeyDown("down")){
            setImage("kelinci-down.png");
            setLocation(getX(),getY()+2);
        }
        if(Greenfoot.isKeyDown("left")){
            setImage("kelinci-left.png");
            setLocation(getX()-2,getY());
        }
        if(Greenfoot.isKeyDown("right")){
            setImage("Kelinci.png");
            setLocation(getX()+2,getY());
        }
        MakanWortel();
        cekScore();
        getWorld().showText("Score: "+JumlahWortelDimakan,100,50);
    }    
    public void MakanWortel(){
        Actor getWortel =getOneIntersectingObject(Wortel.class);
        if(getWortel != null){
            getWorld().removeObject(getWortel);
            Greenfoot.playSound("Slurp.wav");
            JumlahWortelDimakan++;
        }
       }
       
   public void cekScore(){
        if(JumlahWortelDimakan >9){
            Finish alret_finish = new Finish();
            getWorld().addObject(alret_finish,400,300);
    }
    }
 }

